package com.zybooks.knifty_rachelsiminskiproject;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddYarnDialog extends Dialog {

    private EditText yarnNameEditText, yarnQuantityEditText;
    private Button addButton, cancelButton;
    private OnAddYarnListener onAddYarnListener;

    public AddYarnDialog(Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_add_yarn);

        yarnNameEditText = findViewById(R.id.editTextYarnName);
        yarnQuantityEditText = findViewById(R.id.editTextYarnQuantity);
        addButton = findViewById(R.id.buttonAdd);
        cancelButton = findViewById(R.id.buttonCancel);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String yarnName = yarnNameEditText.getText().toString();

                // Try to parse the quantity, and ensure it is an integer
                int yarnQuantity = 0;
                try {
                    yarnQuantity = Integer.parseInt(yarnQuantityEditText.getText().toString());
                } catch (NumberFormatException e) {
                    // Handle invalid input
                    yarnQuantityEditText.setError("Invalid quantity");
                    return;
                }

                if (onAddYarnListener != null) {
                    onAddYarnListener.onAddYarn(yarnName, yarnQuantity);
                }

                // Clear the input fields and dismiss the dialog after adding yarn
                yarnNameEditText.setText("");
                yarnQuantityEditText.setText("");
                dismiss(); // Close the dialog
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close the dialog if cancelled
                dismiss();
            }
        });
    }

    public void setOnAddYarnListener(OnAddYarnListener listener) {
        this.onAddYarnListener = listener;
    }

    public interface OnAddYarnListener {
        void onAddYarn(String yarnName, int yarnQuantity);
    }
}

package com.zybooks.knifty_rachelsiminskiproject;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DatabaseActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private YarnAdapter yarnAdapter;
    private List<Yarn> yarnList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerViewYarn);

        yarnList = new ArrayList<>();
        yarnAdapter = new YarnAdapter(yarnList);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columns
        recyclerView.setAdapter(yarnAdapter);

        loadYarnItems();

        // Get the Add Yarn button and set the onClick listener
        Button addYarnButton = findViewById(R.id.buttonAddYarn);
        addYarnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddYarnDialog();
            }
        });
    }

    // Method to display the dialog for adding a new yarn
    private void showAddYarnDialog() {
        final AddYarnDialog addYarnDialog = new AddYarnDialog(this);
        addYarnDialog.setOnAddYarnListener(new AddYarnDialog.OnAddYarnListener() {
            @Override
            public void onAddYarn(String yarnName, int yarnQuantity) {
                // Add yarn to the database
                long result = dbHelper.insertYarn(yarnName, yarnQuantity);
                if (result != -1) {
                    loadYarnItems(); // Reload yarn items in RecyclerView
                    Toast.makeText(DatabaseActivity.this, "Yarn added successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(DatabaseActivity.this, "Error adding yarn", Toast.LENGTH_SHORT).show();
                }
            }
        });
        addYarnDialog.show();
    }

    // Method to load all yarn items from the database
    private void loadYarnItems() {
        yarnList.clear();
        Cursor cursor = dbHelper.getAllYarn();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_YARN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_YARN_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_YARN_QUANTITY));

                yarnList.add(new Yarn(id, name, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        yarnAdapter.notifyDataSetChanged();
    }
}

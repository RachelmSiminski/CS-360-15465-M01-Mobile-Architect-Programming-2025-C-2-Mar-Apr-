package com.zybooks.knifty_rachelsiminskiproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "knifty.db";
    private static final int DATABASE_VERSION = 1;

    // User table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Yarn table
    public static final String TABLE_YARN = "yarn";
    public static final String COLUMN_YARN_ID = "id";
    public static final String COLUMN_YARN_NAME = "name";
    public static final String COLUMN_YARN_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT,"
                + COLUMN_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_YARN_TABLE = "CREATE TABLE " + TABLE_YARN + "("
                + COLUMN_YARN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_YARN_NAME + " TEXT,"
                + COLUMN_YARN_QUANTITY + " INTEGER" + ")";
        db.execSQL(CREATE_YARN_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_YARN);
        onCreate(db);
    }

    // Add new user
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1; // if -1, insert failed
    }

    // Check login
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE "
                + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }


    // Add yarn item
    public long insertYarn(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_YARN_NAME, name);
        values.put(COLUMN_YARN_QUANTITY, quantity);

        // Return the row ID of the newly inserted row, or -1 if an error occurred
        return db.insert(TABLE_YARN, null, values);
    }


    // Update yarn item
    public boolean updateYarn(int id, String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_YARN_NAME, name);
        values.put(COLUMN_YARN_QUANTITY, quantity);

        int result = db.update(TABLE_YARN, values, COLUMN_YARN_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Delete yarn item
    public boolean deleteYarn(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_YARN, COLUMN_YARN_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Get all yarn items
    public Cursor getAllYarn() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_YARN, null);
    }
}

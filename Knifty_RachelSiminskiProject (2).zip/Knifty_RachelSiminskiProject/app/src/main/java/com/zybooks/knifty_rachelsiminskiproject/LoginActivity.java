package com.zybooks.knifty_rachelsiminskiproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameField;
    private EditText passwordField;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);

        dbHelper = new DatabaseHelper(this);
    }

    public void loginUser(View view) {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        if (dbHelper.checkUser(username, password)) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, DatabaseActivity.class));
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    public void createAccount(View view) {
        String username = usernameField.getText().toString();
        String password = passwordField.getText().toString();

        if (dbHelper.insertUser(username, password)) {
            Toast.makeText(this, "Account created! Please log in.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account creation failed.", Toast.LENGTH_SHORT).show();
        }
    }
}

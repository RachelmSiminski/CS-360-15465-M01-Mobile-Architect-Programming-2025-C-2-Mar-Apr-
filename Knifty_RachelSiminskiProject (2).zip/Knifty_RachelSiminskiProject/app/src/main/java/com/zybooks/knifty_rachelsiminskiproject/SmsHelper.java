package com.zybooks.knifty_rachelsiminskiproject;

import android.content.Context;
import android.telephony.SmsManager;
import android.widget.Toast;

public class SmsHelper {

    // Method to send an SMS alert (this will be called from the activity)
    public static void sendSMSAlert(Context context, String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(context, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}

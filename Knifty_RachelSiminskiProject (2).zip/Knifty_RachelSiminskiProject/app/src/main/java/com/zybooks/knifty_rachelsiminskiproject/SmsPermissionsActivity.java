package com.zybooks.knifty_rachelsiminskiproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsPermissionsActivity extends AppCompatActivity {

    public static final int SMS_PERMISSION_REQUEST_CODE = 1; // Define the request code for SMS permission

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smspermissions);  // Your layout file for the SMS permission UI

        // Button for requesting permission
        Button requestSMSPermissionButton = findViewById(R.id.requestSMSPermissionButton);
        requestSMSPermissionButton.setOnClickListener(v -> requestSMSPermission());
    }

    // Request SMS permission
    private void requestSMSPermission() {
        // Check if SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission is already granted
            Toast.makeText(this, "SMS Permission already granted", Toast.LENGTH_SHORT).show();
            sendSMSAlert(); // Send SMS if permission is already granted
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "SMS Permission granted", Toast.LENGTH_SHORT).show();
                sendSMSAlert(); // Send SMS after permission is granted
            } else {
                // Permission denied
                Toast.makeText(this, "SMS Permission denied", Toast.LENGTH_SHORT).show();
                // Continue without SMS feature
            }
        }
    }

    // Method to send an SMS alert (you can customize the content)
    private void sendSMSAlert() {
        String phoneNumber = "1234567890"; // Replace with a valid phone number
        String message = "This is a test SMS alert!";

        try {
            SmsHelper.sendSMSAlert(this, phoneNumber, message);
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}

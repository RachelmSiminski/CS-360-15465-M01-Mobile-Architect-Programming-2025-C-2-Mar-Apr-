package com.zybooks.knifty_rachelsiminskiproject;

public class Yarn {
    private int id;
    private String name;
    private int quantity;

    public Yarn(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
}

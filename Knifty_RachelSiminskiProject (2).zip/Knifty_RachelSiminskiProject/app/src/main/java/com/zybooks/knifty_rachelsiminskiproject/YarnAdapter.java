package com.zybooks.knifty_rachelsiminskiproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class YarnAdapter extends RecyclerView.Adapter<YarnAdapter.YarnViewHolder> {

    private List<Yarn> yarnList;

    public YarnAdapter(List<Yarn> yarnList) {
        this.yarnList = yarnList;
    }

    @NonNull
    @Override
    public YarnViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_yarn, parent, false);
        return new YarnViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull YarnViewHolder holder, int position) {
        Yarn yarn = yarnList.get(position);
        holder.nameTextView.setText(yarn.getName());
        holder.quantityTextView.setText("Qty: " + yarn.getQuantity());
    }

    @Override
    public int getItemCount() {
        return yarnList.size();
    }

    static class YarnViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView quantityTextView;

        public YarnViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.textViewYarnName);
            quantityTextView = itemView.findViewById(R.id.textViewYarnQuantity);
        }
    }
}
